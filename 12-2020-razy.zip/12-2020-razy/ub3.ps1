# INPUT PARAMS...
    # $zh0, bytes, DLL to XOR encode
    # $ft4, string, key to use
# OUTPUT: bytes of the XOR encoded DLL

$kf9=0..255;
$gs5=0;
$aw3=$ft4.Length;

# make some transformation on the range 0-255 based on the contents of the key
# $kf9 is now the decode key
0..255 | % {
    $gs5=($gs5+$kf9[$_]+$ft4[$_ % $aw3]) % 256;
    $kf9[$_],$kf9[$gs5]=$kf9[$gs5],$kf9[$_]
}

# XOR bytes in the DLL with more transformations on top of $kf9
$qu2=$gs5=0;
foreach($qz6 in $zh0) {
	$qu2=($qu2+1) % 256;
    $gs5=($gs5+$kf9[$qu2]) % 256;
    $kf9[$qu2],$kf9[$gs5]=$kf9[$gs5],$kf9[$qu2];
    $qz6 -bxor $kf9[($kf9[$qu2]+$kf9[$gs5]) % 256]
}