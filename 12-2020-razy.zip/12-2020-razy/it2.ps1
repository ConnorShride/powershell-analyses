# INPUT PARAMS...
    # $hf2: path to a reg key
    # $tp9: value to set for a property "(Default)"
# OUTPUT: 
    # sets the registry property (Default):<$tp9>

New-ItemProperty -Path $hf2 -Name "(Default)" -PropertyType String -Value $tp9 -force|Out-Null